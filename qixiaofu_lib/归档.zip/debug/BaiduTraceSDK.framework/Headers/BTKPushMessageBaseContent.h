//
//  BTKPushMessageBaseContent.h
//  BaiduTraceSDK
//
//  Created by Daniel Bey on 2017年03月27日.
//  Copyright © 2017 Daniel Bey. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 推送消息内容的基类，开发者不需要关注此类
@interface BTKPushMessageBaseContent : NSObject

@end
