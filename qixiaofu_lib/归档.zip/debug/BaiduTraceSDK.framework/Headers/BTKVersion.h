//
//  BTKVersion.h
//  BaiduTraceSDK
//
//  Created by Daniel Bey on 2017年04月17日.
//  Copyright © 2017 Daniel Bey. All rights reserved.
//

#import <UIKit/UIKit.h>

// SDK当前的版本号
UIKIT_EXTERN NSString * const BTKVersionNumber;
