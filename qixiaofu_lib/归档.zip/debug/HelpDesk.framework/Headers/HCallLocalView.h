//
//  HCallLocalView.h
//  helpdesk_sdk
//
//  Created by afanda on 3/15/17.
//  Copyright © 2017 hyphenate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMCallLocalView.h"
#import "HCallEnum.h"

@interface HCallLocalView : EMCallLocalView

@property(nonatomic,assign) HCallViewScaleMode hScaleMode;

@end
