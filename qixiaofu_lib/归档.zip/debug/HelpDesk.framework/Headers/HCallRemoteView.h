//
//  HCallRemoteView.h
//  helpdesk_sdk
//
//  Created by afanda on 3/15/17.
//  Copyright © 2017 hyphenate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMCallRemoteView.h"
#import "HCallEnum.h"

@interface HCallRemoteView : EMCallRemoteView

@property(nonatomic,assign) HCallViewScaleMode hScaleMode;

@end
