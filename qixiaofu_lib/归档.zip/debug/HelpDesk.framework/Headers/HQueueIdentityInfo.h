//
//  HQueueIdentityInfo.h
//  helpdesk_sdk
//
//  Created by 赵 蕾 on 16/5/5.
//  Copyright © 2016年 hyphenate. All rights reserved.
//  指定技能组

#import "HContent.h"

@interface HQueueIdentityInfo : HContent
@property (nonatomic) NSString * queueIdentity;
@end
