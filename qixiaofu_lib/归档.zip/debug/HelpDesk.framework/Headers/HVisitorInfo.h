//
//  VisitorInfo.h
//  helpdesk_sdk
//
//  Created by 赵 蕾 on 16/5/5.
//  Copyright © 2016年 hyphenate. All rights reserved.
//

#import "HContent.h"

@interface HVisitorInfo : HContent
@property (nonatomic) NSString* name;
@property (nonatomic) NSString* qq;
@property (nonatomic) NSString* companyName;
@property (nonatomic) NSString* nickName;
@property (nonatomic) NSString* phone;
@property (nonatomic) NSString* desc;
@property (nonatomic) NSString* email;
@end
