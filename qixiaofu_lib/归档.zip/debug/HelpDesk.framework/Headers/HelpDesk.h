//
//  HelpDesk.h
//  HelpDesk
//
//  Created by afanda on 5/16/17.
//  Copyright © 2017 hyphenate. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HelpDesk.
FOUNDATION_EXPORT double HelpDeskVersionNumber;

//! Project version string for HelpDesk.
FOUNDATION_EXPORT const unsigned char HelpDeskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelpDesk/PublicHeader.h>

#import <HelpDesk/HChatClient.h>
#import <HelpDesk/HCall.h>
#import <HelpDesk/HChatClient+call.h>


